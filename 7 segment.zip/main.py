print("Hello, ESP32!")


from machine import Pin
from utime import sleep

pins = [
    Pin(2, Pin.OUT),  # A
    Pin(4, Pin.OUT),  # B
    Pin(5, Pin.OUT),  # C
    Pin(15, Pin.OUT),  # D
    Pin(19, Pin.OUT),  # E
    Pin(27, Pin.OUT),  # F
    Pin(26, Pin.OUT),  # G
]

digits = [
  #{ a ,b, c, d, e, f, g,dp}
    [0, 0, 0, 0, 0, 0, 1, 0], # 0
    [1, 0, 0, 1, 1, 1, 1, 1], # 1
    [0, 0, 1, 0, 0, 1, 0, 1], # 2 
    [0, 0, 0, 0, 1, 1, 0, 1], # 3
    [1, 0, 0, 1, 1, 0, 0, 1], # 4
    [0, 1, 0, 0, 1, 0, 0, 1], # 5
    [0, 1, 0, 0, 0, 0, 0, 1], # 6
    [0, 0, 0, 1, 1, 1, 1, 1], # 7
    [0, 0, 0, 0, 0, 0, 0, 1], # 8
    [0, 0, 0, 1, 1, 0, 0, 1], # 9
    
]
while True:
        # Ascending counter
        for i in range(len(digits)):
            
            for j in range(len(pins)):
                pins[j].value(digits[i][j])
            sleep(0.5)
   
